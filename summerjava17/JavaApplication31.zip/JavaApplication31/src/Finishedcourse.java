
public class Finishedcourse {
    private double grade;
    private boolean passedcourse;
    if ( double grade==0){
    System.out.println("the course is passed");
}else{ 
    System.out.println("the course is passed");
}
    
}
