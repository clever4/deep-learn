
 import Java.util.*;

public class JavaApplication31{
        private String _name;
        private String _house;
        private String _blood;
        private String _Schooltech;
        
        public JavaApplication31(String JavaApplication31){
            _name = "Harry potter";
            _house = "Grifindoor";
            _blood ="pure";
            _Schooltech ="Professor";
         
            System.out.println(_name);
            System.out.println(_house);
             System.out.println(_blood);
              System.out.println(_Schooltech);
            if (Schooltech = "absent" ){
              System.out.print("absent");
            }else{ System.out.print("present");
        
    }
    
}
