
public class course {
    private String name;
    private double mingrade;
    private String professor;
    private int year;
    public course(String course){
        name="Wizardcourse";
        mingrade=0;
        professor="Snip";
        year=1990;
        System.out.prinln=(name);
         System.out.prinln=(mingrade);      
         System.out.prinln=(professor);
         System.out.prinln=(year);}
    public course (String name,double mingrade){
    } public String getname(){return name;}
      void setname(String name){
          System.out.println("name");}
      public double getmingrade(){return mingrade;}
      void  setmingrade(double mingrade){
          System.out.println(mingrade);
      }
       public String getprofessor(){return professor;}
      void setprofessor(String professor){ 
          System.out.println(professor);}
      
        public int getyear(){return year;}
      void setprofessor(int year){ 
          System.out.println(professor);}
          
            
            
        }
         


        
        
        
    }
    
}
