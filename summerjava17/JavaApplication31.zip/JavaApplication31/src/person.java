
public abstract  class person {
    private String name;
    private String  house;
    private  String blood;
    private  String Schooltech;
    public  person (String name, String house,String blood,String Schooltech)
    { System.out.println("");
        this.name=name;
      this .house=house;
      this .blood=blood;
      this.Schooltech=Schooltech;
      
    }public String getname()
               {
          return name;
      }//public method to set the name
       void setname(String name){
          System.out.println=(name);
       }public String gethouse(){
              return house;
          }void sethouse(String house){
              System.out.print(house);
           }
          public String getblood(){
                  return blood;}
                 void setblood(String blood){
                     System.out.print=(blood);
                         }

          
          
          
          
      }
      
}
            
    
    
    
    
}
